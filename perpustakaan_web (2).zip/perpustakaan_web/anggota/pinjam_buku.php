<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
redirectIfNotAnggota();

// Inisialisasi session messages
if (!isset($_SESSION['error'])) $_SESSION['error'] = null;
if (!isset($_SESSION['success'])) $_SESSION['success'] = null;

// Dapatkan data anggota
$user_id = $_SESSION['user_id'];

$query_anggota = "SELECT a.id, a.nama FROM anggota a WHERE a.user_id = :user_id";
$stmt_anggota = oci_parse($conn, $query_anggota);
oci_bind_by_name($stmt_anggota, ":user_id", $user_id);

if (!oci_execute($stmt_anggota)) {
    $e = oci_error($stmt_anggota);
    die("Query error: " . htmlentities($e['message']));
}

$anggota = oci_fetch_assoc($stmt_anggota);
$anggota_id = $anggota['ID'];
$buku_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$buku = null;

if ($buku_id > 0) {
    $query_buku = "SELECT b.*, k.nama as kategori FROM buku b 
                  LEFT JOIN kategori k ON b.kategori_id = k.id 
                  WHERE b.id = :buku_id";
    $stmt_buku = oci_parse($conn, $query_buku);
    oci_bind_by_name($stmt_buku, ":buku_id", $buku_id);

    if (!oci_execute($stmt_buku)) {
        $e = oci_error($stmt_buku);
        die("Query error: " . htmlentities($e['message']));
    }

    $buku = oci_fetch_assoc($stmt_buku);
}

// Proses form peminjaman
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buku_id'])) {
    $buku_id = (int)$_POST['buku_id'];

    // Validasi checkbox persetujuan
    if (!isset($_POST['agree'])) {
        $_SESSION['error'] = "Anda harus menyetujui syarat dan ketentuan peminjaman";
        header("Location: pinjam_buku.php?id=" . $buku_id);
        exit();
    }

    // 1. Validasi stok buku tersedia
    $query_buku = "SELECT jumlah FROM buku WHERE id = :buku_id FOR UPDATE";
    $stmt_buku = oci_parse($conn, $query_buku);
    oci_bind_by_name($stmt_buku, ":buku_id", $buku_id);

    if (!oci_execute($stmt_buku)) {
        $e = oci_error($stmt_buku);
        die("Query error: " . htmlentities($e['message']));
    }

    $buku = oci_fetch_assoc($stmt_buku);

    if ((int)$buku['JUMLAH'] < 1) {
        $_SESSION['error'] = "Buku tidak tersedia untuk dipinjam";
        header("Location: buku.php");
        exit();
    }

    // 2. Mulai transaksi (Oracle tidak punya begin_transaction, jadi kita langsung eksekusi)
    try {
        // 3. Kurangi stok buku
        $query_kurangi = "UPDATE buku SET jumlah = jumlah - 1 WHERE id = :buku_id";
        $stmt_kurangi = oci_parse($conn, $query_kurangi);
        oci_bind_by_name($stmt_kurangi, ":buku_id", $buku_id);

        if (!oci_execute($stmt_kurangi)) {
            $e = oci_error($stmt_kurangi);
            throw new Exception(htmlentities($e['message']));
        }

        // 4. Catat peminjaman
        $tanggal_pinjam = date('Y-m-d');
        $tanggal_kembali = date('Y-m-d', strtotime('+7 days'));

        $query_pinjam = "INSERT INTO peminjaman 
                        (buku_id, anggota_id, tanggal_pinjam, tanggal_kembali, status) 
                        VALUES (:buku_id, :anggota_id, TO_DATE(:tanggal_pinjam, 'YYYY-MM-DD'), TO_DATE(:tanggal_kembali, 'YYYY-MM-DD'), 'dipinjam')";

        $stmt_pinjam = oci_parse($conn, $query_pinjam);
        oci_bind_by_name($stmt_pinjam, ":buku_id", $buku_id);
        oci_bind_by_name($stmt_pinjam, ":anggota_id", $anggota_id);
        oci_bind_by_name($stmt_pinjam, ":tanggal_pinjam", $tanggal_pinjam);
        oci_bind_by_name($stmt_pinjam, ":tanggal_kembali", $tanggal_kembali);

        if (!oci_execute($stmt_pinjam)) {
            $e = oci_error($stmt_pinjam);
            throw new Exception(htmlentities($e['message']));
        }

        // Commit (Oracle otomatis commit jika tidak error)
        oci_commit($conn);

        $_SESSION['success'] = "Buku berhasil dipinjam! Harap dikembalikan sebelum " . date('d/m/Y', strtotime($tanggal_kembali));
        header("Location: peminjaman.php");
        exit();
    } catch (Exception $e) {
        // Rollback (Oracle tidak punya rollback eksplisit, tapi tidak akan execute statement jika error)
        oci_rollback($conn);
        $_SESSION['error'] = "Gagal meminjam buku: " . $e->getMessage();
        header("Location: pinjam_buku.php?id=" . $buku_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pinjam Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> 
    <style>
        .terms-box {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        .book-cover {
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-4">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (!$buku): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> Buku tidak ditemukan
            </div>
            <a href="buku.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar Buku
            </a>
        <?php elseif ((int)$buku['JUMLAH'] < 1): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> Maaf, buku <strong><?= htmlspecialchars($buku['JUDUL']) ?></strong> sedang tidak tersedia
            </div>
            <a href="buku.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar Buku
            </a>
        <?php else: ?>
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4><i class="fas fa-book-reader"></i> Form Peminjaman Buku</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="book-cover mb-4">
                                <?php if (!empty($buku['COVER_URL'])): ?>
                                    <img src="<?= htmlspecialchars($buku['COVER_URL']) ?>" class="img-fluid rounded" style="max-height:100%">
                                <?php else: ?>
                                    <i class="fas fa-book-open fa-5x text-secondary"></i>
                                <?php endif; ?>
                            </div>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($buku['JUDUL']) ?></h5>
                                    <h6 class="card-subtitle mb-2 text-muted"><?= htmlspecialchars($buku['PENGARANG']) ?></h6>
                                    <p class="card-text">
                                        <strong><i class="fas fa-tag"></i> Kategori:</strong> <?= htmlspecialchars($buku['KATEGORI'] ?? 'Umum') ?><br>
                                        <strong><i class="fas fa-building"></i> Penerbit:</strong> <?= htmlspecialchars($buku['PENERBIT']) ?><br>
                                        <strong><i class="fas fa-calendar-alt"></i> Tahun:</strong> <?= $buku['TAHUN_TERBIT'] ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-user"></i> Data Peminjam</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <strong>Nama Peminjam:</strong> <?= htmlspecialchars($anggota['NAMA']) ?>
                                    </div>
                                    <div class="mb-3">
                                        <strong>Tanggal Pinjam:</strong> <?= date('d/m/Y') ?>
                                    </div>
                                    <div class="mb-3">
                                        <strong>Batas Pengembalian:</strong> 
                                        <span class="text-success">
                                            <?= date('d/m/Y', strtotime('+7 days')) ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0"><i class="fas fa-file-contract"></i> Syarat dan Ketentuan</h5>
                                </div>
                                <div class="card-body">
                                    <div class="terms-box mb-3">
                                        <ol>
                                            <li>Buku harus dikembalikan tepat waktu sebelum tanggal jatuh tempo.</li>
                                            <li>Denda keterlambatan Rp 5.000 per hari.</li>
                                            <li>Buku yang hilang atau rusak harus diganti dengan buku yang sama atau membayar 2x harga buku.</li>
                                            <li>Peminjaman dapat diperpanjang maksimal 1 kali selama 7 hari.</li>
                                            <li>Perpustakaan berhak membatasi peminjaman jika melanggar peraturan.</li>
                                        </ol>
                                    </div>
                                    <form method="POST">
                                        <input type="hidden" name="buku_id" value="<?= $buku['ID'] ?>">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" id="agree" name="agree" required>
                                            <label class="form-check-label" for="agree">
                                                Saya telah membaca dan menyetujui semua syarat dan ketentuan di atas
                                            </label>
                                        </div>
                                        <div class="d-grid gap-2">
                                            <button type="submit" class="btn btn-primary btn-lg">
                                                <i class="fas fa-check-circle"></i> Konfirmasi Peminjaman
                                            </button>
                                            <a href="detail_buku.php?id=<?= $buku['ID'] ?>" class="btn btn-secondary btn-lg">
                                                <i class="fas fa-times-circle"></i> Batal
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
    <script>
        // Auto close alert setelah 5 detik
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.classList.add('fade');
                alert.addEventListener('transitionend', () => alert.remove());
            });
        }, 5000);
    </script>
</body>
</html>