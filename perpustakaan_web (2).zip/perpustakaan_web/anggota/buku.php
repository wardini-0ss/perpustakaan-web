<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAnggota();

// Ambil parameter pencarian
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$kategori = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12; // 12 item per halaman
$offset = ($page - 1) * $per_page;

// Dapatkan koneksi Oracle
global $conn;

// Query dasar
$query = "SELECT b.*, k.nama as kategori 
          FROM buku b 
          LEFT JOIN kategori k ON b.kategori_id = k.id
          WHERE b.jumlah > 0";

// Tambahkan filter pencarian
if (!empty($search)) {
    $query .= " AND (b.judul LIKE :search OR b.pengarang LIKE :search OR b.penerbit LIKE :search)";
}

// Tambahkan filter kategori
if ($kategori > 0) {
    $query .= " AND b.kategori_id = :kategori";
}

// Urutkan dan batasi hasil
$query .= " ORDER BY b.judul ASC OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";

// Siapkan statement
$stmt = oci_parse($conn, $query);

// Bind parameter berdasarkan kondisi
if (!empty($search)) {
    $search_param = '%' . $search . '%';
    oci_bind_by_name($stmt, ":search", $search_param);
}

if ($kategori > 0) {
    oci_bind_by_name($stmt, ":kategori", $kategori);
}

oci_bind_by_name($stmt, ":offset", $offset);
oci_bind_by_name($stmt, ":limit", $per_page);

// Eksekusi query
if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$buku = [];
while ($row = oci_fetch_assoc($stmt)) {
    $buku[] = $row;
}
oci_free_statement($stmt);

// Hitung total buku untuk pagination
$count_query = "SELECT COUNT(*) as total FROM buku b WHERE b.jumlah > 0";

if (!empty($search)) {
    $count_query .= " AND (b.judul LIKE '%" . $search . "%' OR b.pengarang LIKE '%" . $search . "%' OR b.penerbit LIKE '%" . $search . "%')";
}

if ($kategori > 0) {
    $count_query .= " AND b.kategori_id = $kategori";
}

$count_stmt = oci_parse($conn, $count_query);
if (!oci_execute($count_stmt)) {
    $e = oci_error($count_stmt);
    die("Count query error: " . htmlentities($e['message']));
}

$total_row = oci_fetch_assoc($count_stmt);
oci_free_statement($count_stmt);

$total_pages = ceil($total_row['TOTAL'] / $per_page);

// Ambil daftar kategori untuk dropdown filter
$kategori_result = [];
$kategori_stmt = oci_parse($conn, "SELECT * FROM kategori ORDER BY nama");
if (!oci_execute($kategori_stmt)) {
    $e = oci_error($kategori_stmt);
    die("Kategori query error: " . htmlentities($e['message']));
}

while ($row = oci_fetch_assoc($kategori_stmt)) {
    $kategori_result[] = $row;
}
oci_free_statement($kategori_stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">    
    <style>
        .card-book {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .book-cover {
            position: relative;
            width: 100%;
            padding-top: 150%; /* Rasio persegi */
            overflow: hidden;
            background-color: #f8f9fa;
        }

        .book-cover img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .card-footer {
            margin-top: auto;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-4">
        <h2 class="mb-4">Daftar Buku</h2>

        <!-- Search and Filter Section -->
        <div class="search-container mb-4">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Cari buku..." value="<?= htmlspecialchars($search); ?>">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </div>
                <div class="col-md-4">
                    <select name="kategori" class="form-select">
                        <option value="0">Semua Kategori</option>
                        <?php foreach ($kategori_result as $cat): ?>
                            <option value="<?= $cat['ID']; ?>" <?= ($kategori == $cat['ID']) ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($cat['NAMA']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-outline-primary w-100">Filter</button>
                </div>
            </form>
        </div>

        <!-- Book List -->
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
            <?php foreach ($buku as $row): ?>
                <div class="col">
                    <div class="card card-book h-100 shadow-sm">
                        <div class="book-cover">
                            <?php if (!empty($row['COVER_URL'])): ?>
                                <img src="<?= htmlspecialchars($row['COVER_URL']); ?>" alt="Cover Buku">
                            <?php else: ?>
                                <i class="fas fa-book-open fa-4x text-muted d-flex align-items-center justify-content-center" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></i>
                            <?php endif; ?>
                        </div>

                        <span class="badge bg-<?= ($row['JUMLAH'] > 0) ? 'success' : 'danger'; ?> position-absolute top-0 end-0 m-2">
                            <?= ($row['JUMLAH'] > 0) ? 'Tersedia' : 'Habis'; ?>
                        </span>

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-1"><?= htmlspecialchars($row['JUDUL']); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?= htmlspecialchars($row['PENGARANG']); ?></h6>
                            <div class="book-meta mt-auto">
                                <small class="text-muted d-block">
                                    <i class="fas fa-bookmark"></i> <?= htmlspecialchars($row['KATEGORI'] ?? 'Umum'); ?>
                                </small>
                                <small class="text-muted d-block">
                                    <i class="fas fa-building"></i> <?= htmlspecialchars($row['PENERBIT']); ?>
                                </small>
                                <small class="text-muted d-block">
                                    <i class="fas fa-calendar-alt"></i> <?= $row['TAHUN_TERBIT']; ?>
                                </small>
                                <small class="text-muted d-block">
                                    <i class="fas fa-copy"></i> Stok: <?= $row['JUMLAH']; ?>
                                </small>
                            </div>
                        </div>

                        <div class="card-footer bg-transparent border-top-0">
                            <div class="d-grid gap-2">
                                <a href="detail_buku.php?id=<?= $row['ID']; ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-info-circle"></i> Detail
                                </a>
                                <?php if ($row['JUMLAH'] > 0): ?>
                                    <a href="pinjam_buku.php?id=<?= $row['ID']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-book-reader"></i> Pinjam
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        <i class="fas fa-times-circle"></i> Tidak Tersedia
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-5">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?= $page - 1; ?>&search=<?= urlencode($search); ?>&kategori=<?= $kategori; ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?= $i; ?>&search=<?= urlencode($search); ?>&kategori=<?= $kategori; ?>">
                                <?= $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?= $page + 1; ?>&search=<?= urlencode($search); ?>&kategori=<?= $kategori; ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

        <?php if (empty($buku)): ?>
            <div class="alert alert-info mt-4">
                <i class="fas fa-info-circle"></i> Tidak ada buku yang ditemukan.
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>    
    <script>
        document.querySelector('select[name="kategori"]').addEventListener('change', function() {
            this.form.submit();
        });
    </script>
</body>
</html>