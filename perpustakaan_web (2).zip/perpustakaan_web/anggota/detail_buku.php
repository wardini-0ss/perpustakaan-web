<?php
require_once '../includes/auth.php';
redirectIfNotAnggota();

if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit();
}

$buku_id = (int)$_GET['id'];

// Dapatkan koneksi Oracle
global $conn;

// Ambil detail buku
$query = "SELECT b.*, k.nama as kategori 
          FROM buku b 
          LEFT JOIN kategori k ON b.kategori_id = k.id
          WHERE b.id = :buku_id";

$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":buku_id", $buku_id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$buku = oci_fetch_assoc($stmt);

if (!$buku) {
    header("Location: buku.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Buku - <?php echo htmlspecialchars($buku['JUDUL']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
    <style>
        .book-cover-detail {
            height: 400px;
            object-fit: contain;
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            padding: 20px;
        }
        .book-meta {
            border-left: 3px solid #0d6efd;
            padding-left: 15px;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="book-cover-detail">
                    <?php if (!empty($buku['COVER_URL'])): ?>
                        <img src="<?php echo htmlspecialchars($buku['COVER_URL']); ?>" class="img-fluid" alt="Cover Buku">
                    <?php else: ?>
                        <i class="fas fa-book-open fa-7x"></i>
                    <?php endif; ?>
                </div>
                
                <div class="d-grid gap-2 mt-3">
                    <?php if ($buku['JUMLAH'] > 0): ?>
                    <a href="pinjam_buku.php?id=<?php echo $buku['ID']; ?>" class="btn btn-lg btn-primary">
                        <i class="fas fa-book-reader"></i> Pinjam Buku
                    </a>
                    <?php else: ?>
                    <button class="btn btn-lg btn-secondary" disabled>
                        <i class="fas fa-times-circle"></i> Tidak Tersedia
                    </button>
                    <?php endif; ?>
                    <a href="buku.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali ke Daftar
                    </a>
                </div>
            </div>
            
            <div class="col-md-8">
                <h2><?php echo htmlspecialchars($buku['JUDUL']); ?></h2>
                <h4 class="text-muted"><?php echo htmlspecialchars($buku['PENGARANG']); ?></h4>
                
                <div class="book-meta my-4">
                    <p><strong>Penerbit:</strong> <?php echo htmlspecialchars($buku['PENERBIT']); ?></p>
                    <p><strong>Tahun Terbit:</strong> <?php echo $buku['TAHUN_TERBIT']; ?></p>
                    <p><strong>Kategori:</strong> <?php echo htmlspecialchars($buku['KATEGORI'] ?? 'Umum'); ?></p>
                    <p><strong>ISBN:</strong> <?php echo $buku['ISBN'] ? htmlspecialchars($buku['ISBN']) : '-'; ?></p>
                    <p>
                        <strong>Status:</strong> 
                        <span class="badge bg-<?php echo ($buku['JUMLAH'] > 0) ? 'success' : 'danger'; ?>">
                            <?php echo ($buku['JUMLAH'] > 0) ? 'Tersedia ('.$buku['JUMLAH'].' eks)' : 'Habis'; ?>
                        </span>
                    </p>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="mb-0">Deskripsi Buku</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($buku['DESKRIPSI'])): ?>
                            <p><?php 
                                // Jika deskripsi bertipe CLOB
                                $deskripsi = $buku['DESKRIPSI'];
                                if ($deskripsi instanceof OCILob) {
                                    $deskripsi = $deskripsi->read(4096);
                                }
                                echo nl2br(htmlspecialchars($deskripsi)); 
                            ?></p>
                        <?php else: ?>
                            <p class="text-muted">Tidak ada deskripsi tersedia untuk buku ini.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>