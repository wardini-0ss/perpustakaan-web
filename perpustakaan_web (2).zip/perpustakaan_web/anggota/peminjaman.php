<?php
require_once '../includes/auth.php';
redirectIfNotAnggota();

// Dapatkan koneksi Oracle
global $conn;

// Dapatkan data anggota
$user_id = $_SESSION['user_id'];
$query = "SELECT a.id FROM anggota a JOIN users u ON a.user_id = u.id WHERE u.id = :user_id";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":user_id", $user_id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$anggota = oci_fetch_assoc($stmt);
oci_free_statement($stmt);

// Ambil data peminjaman
$query_peminjaman = "SELECT p.*, b.judul, b.pengarang 
                    FROM peminjaman p
                    JOIN buku b ON p.buku_id = b.id
                    WHERE p.anggota_id = :anggota_id
                    ORDER BY p.tanggal_pinjam DESC";

$stmt_peminjaman = oci_parse($conn, $query_peminjaman);
oci_bind_by_name($stmt_peminjaman, ":anggota_id", $anggota['ID']);

if (!oci_execute($stmt_peminjaman)) {
    $e = oci_error($stmt_peminjaman);
    die("Query error: " . htmlentities($e['message']));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <h2>Peminjaman Saya</h2>
        
        <div class="card mt-4">
            <div class="card-header">
                Daftar Peminjaman
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Judul Buku</th>
                                <th>Pengarang</th>
                                <th>Tanggal Pinjam</th>
                                <th>Tanggal Kembali</th>
                                <th>Status</th>
                                <th>Denda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = oci_fetch_assoc($stmt_peminjaman)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['JUDUL']); ?></td>
                                <td><?php echo htmlspecialchars($row['PENGARANG']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['TANGGAL_PINJAM'])); ?></td>
                                <td>
                                    <?php 
                                    if (!empty($row['TANGGAL_KEMBALI'])) {
                                        echo date('d/m/Y', strtotime($row['TANGGAL_KEMBALI']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <span class="badge 
                                        <?php 
                                        if ($row['STATUS'] == 'dipinjam') echo 'bg-warning';
                                        elseif ($row['STATUS'] == 'dikembalikan') echo 'bg-success';
                                        else echo 'bg-danger';
                                        ?>">
                                        <?php echo ucfirst(htmlspecialchars($row['STATUS'])); ?>
                                    </span>
                                </td>
                                <td>Rp <?php echo number_format((int)$row['DENDA'], 0, ',', '.'); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>