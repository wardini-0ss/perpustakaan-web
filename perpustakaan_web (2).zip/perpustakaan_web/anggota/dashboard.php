<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAnggota();

global $conn;

error_reporting(E_ALL);
ini_set('display_errors', 1);

function safe_output($value) {
    if ($value instanceof OCILob) {
        return htmlspecialchars($value->read(4096));
    }
    return htmlspecialchars((string)$value);
}

// Dapatkan data anggota
$user_id = $_SESSION['user_id'];

$query = "SELECT a.* FROM anggota a JOIN users u ON a.user_id = u.id WHERE u.id = :user_id";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":user_id", $user_id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}
$anggota = oci_fetch_assoc($stmt);
oci_free_statement($stmt);

// Hitung peminjaman aktif
$query_peminjaman = "SELECT COUNT(*) AS total FROM peminjaman 
                    WHERE anggota_id = :anggota_id AND status = 'dipinjam'";
$stmt_peminjaman = oci_parse($conn, $query_peminjaman);
oci_bind_by_name($stmt_peminjaman, ":anggota_id", $anggota['ID']);

if (!oci_execute($stmt_peminjaman)) {
    $e = oci_error($stmt_peminjaman);
    die("Query error: " . htmlentities($e['message']));
}
$peminjaman_aktif = oci_fetch_assoc($stmt_peminjaman);
oci_free_statement($stmt_peminjaman);

// Hitung total peminjaman
$query_total = "SELECT COUNT(*) AS total FROM peminjaman 
               WHERE anggota_id = :anggota_id";
$stmt_total = oci_parse($conn, $query_total);
oci_bind_by_name($stmt_total, ":anggota_id", $anggota['ID']);

if (!oci_execute($stmt_total)) {
    $e = oci_error($stmt_total);
    die("Query error: " . htmlentities($e['message']));
}
$total_peminjaman = oci_fetch_assoc($stmt_total);
oci_free_statement($stmt_total);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Anggota - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
        }
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .dashboard-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .profile-card {
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border: none;
            transition: transform 0.3s;
        }
        .profile-card:hover {
            transform: translateY(-5px);
        }
        .profile-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.5rem;
        }
        .stat-card {
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border: none;
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .card-body {
            padding: 2rem;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        .btn-custom {
            background-color: var(--primary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-custom:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: -70px auto 20px;
            display: block;
            background-color: #ecf0f1;
        }
        .profile-detail {
            padding: 0 1.5rem 1.5rem;
        }
        .detail-item {
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
        .detail-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .detail-label {
            font-weight: 600;
            color: var(--secondary-color);
        }
        .quick-actions {
            margin-top: 2rem;
        }
        .action-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 1.5rem;
            border-radius: 15px;
            background-color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
            text-decoration: none;
            color: var(--dark-color);
            height: 100%;
        }
        .action-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            color: var(--primary-color);
        }
        .action-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-5 fw-bold mb-3">Dashboard Anggota</h1>
                    <p class="lead mb-0">Selamat datang kembali, <?php echo safe_output($anggota['NAMA']); ?></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <span class="badge bg-light text-primary fs-6 p-3">
                        <i class="fas fa-user-circle me-2"></i>Status: Anggota Aktif
                    </span>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <!-- Profil Anggota -->
            <div class="col-lg-4 mb-4">
                <div class="card profile-card">
                    <div class="profile-header text-center">
                        <h4 class="mb-0">Profil Saya</h4>
                    </div>
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($anggota['NAMA']); ?>&background=3498db&color=fff&size=200" 
                         alt="Profile" class="profile-avatar">
                    <div class="profile-detail">
                        <div class="detail-item">
                            <div class="detail-label"><i class="fas fa-user me-2"></i>Nama Lengkap</div>
                            <div><?php echo safe_output($anggota['NAMA']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label"><i class="fas fa-envelope me-2"></i>Email</div>
                            <div><?php echo safe_output($anggota['EMAIL']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label"><i class="fas fa-map-marker-alt me-2"></i>Alamat</div>
                            <div><?php echo safe_output($anggota['ALAMAT']); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label"><i class="fas fa-phone me-2"></i>Telepon</div>
                            <div><?php echo safe_output($anggota['TELEPON']); ?></div>
                        </div>
                        <div class="text-center mt-3">
                            <a href="edit_profil.php" class="btn btn-outline-primary">
                                <i class="fas fa-edit me-2"></i>Edit Profil
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Statistik dan Quick Actions -->
            <div class="col-lg-8">
                <div class="row mb-4">
                    <div class="col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body text-center">
                                <div class="stat-icon">
                                    <i class="fas fa-book-open"></i>
                                </div>
                                <div class="stat-number">
                                    <?php echo $peminjaman_aktif['TOTAL']; ?>
                                </div>
                                <h5 class="card-title">Peminjaman Aktif</h5>
                                <a href="peminjaman.php" class="btn btn-custom mt-3">
                                    <i class="fas fa-list me-2"></i>Lihat Detail
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body text-center">
                                <div class="stat-icon">
                                    <i class="fas fa-history"></i>
                                </div>
                                <div class="stat-number">
                                    <?php echo $total_peminjaman['TOTAL']; ?>
                                </div>
                                <h5 class="card-title">Total Peminjaman</h5>
                                <a href="peminjaman.php" class="btn btn-custom mt-3">
                                    <i class="fas fa-list me-2"></i>Lihat Riwayat
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Quick Actions -->
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Aksi Cepat</h5>
                    </div>
                    <div class="card-body">
                        <div class="row quick-actions">
                            <div class="col-md-4 mb-3">
                                <a href="buku.php" class="action-btn">
                                    <div class="action-icon">
                                        <i class="fas fa-search"></i>
                                    </div>
                                    <h6>Cari Buku</h6>
                                    <small class="text-muted">Temukan buku baru</small>
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="peminjaman.php" class="action-btn">
                                    <div class="action-icon">
                                        <i class="fas fa-book-reader"></i>
                                    </div>
                                    <h6>Peminjaman</h6>
                                    <small class="text-muted">Lihat status pinjaman</small>
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="#" class="action-btn"> 
                                    <div class="action-icon">
                                        <i class="fas fa-bookmark"></i>
                                    </div>
                                    <h6>Favorit</h6>
                                    <small class="text-muted">Buku favorit Anda</small>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Notifikasi Terbaru -->
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Notifikasi Terbaru</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i> 
                            Batas pengembalian buku "Pemrograman Web Modern" besok!
                        </div>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i> 
                            Buku "Belajar Laravel untuk Pemula" telah tersedia
                        </div>
                        <a href="#" class="btn btn-outline-primary w-100">
                            <i class="fas fa-bell me-2"></i>Lihat Semua Notifikasi
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card, .profile-card, .action-btn');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>