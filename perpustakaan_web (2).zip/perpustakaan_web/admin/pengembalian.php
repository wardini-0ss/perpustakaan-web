<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: peminjaman.php");
    exit();
}

$id = (int)$_GET['id'];

// Dapatkan koneksi Oracle
global $conn;

// Ambil data peminjaman
$query = "SELECT p.*, b.judul, b.id as buku_id 
          FROM peminjaman p
          JOIN buku b ON p.buku_id = b.id
          WHERE p.id = :id AND p.status = 'dipinjam'";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id", $id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$peminjaman = oci_fetch_assoc($stmt);

if (!$peminjaman) {
    header("Location: peminjaman.php");
    exit();
}

// Hitung denda jika terlambat
$tanggal_kembali = date('Y-m-d');
$terlambat = strtotime($tanggal_kembali) > strtotime($peminjaman['TANGGAL_KEMBALI']);
$denda = 0;

if ($terlambat) {
    $hari_terlambat = floor((time() - strtotime($peminjaman['TANGGAL_KEMBALI'])) / (60 * 60 * 24));
    $denda = $hari_terlambat * 5000; // Denda Rp 5.000 per hari
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Nonaktifkan autocommit
        oci_execute($conn, OCI_NO_AUTO_COMMIT);

        // Update status peminjaman
        $update_query = "UPDATE peminjaman SET 
                        status = 'dikembalikan', 
                        tanggal_kembali = TO_DATE(:tanggal_kembali, 'YYYY-MM-DD'),
                        denda = :denda
                        WHERE id = :id";
        $stmt_update = oci_parse($conn, $update_query);
        oci_bind_by_name($stmt_update, ":tanggal_kembali", $tanggal_kembali);
        oci_bind_by_name($stmt_update, ":denda", $denda);
        oci_bind_by_name($stmt_update, ":id", $id);

        if (!oci_execute($stmt_update)) {
            throw new Exception("Gagal memperbarui status peminjaman");
        }

        // Tambah stok buku kembali
        $buku_id = $peminjaman['BUKU_ID'];
        $update_buku = "UPDATE buku SET jumlah = jumlah + 1 WHERE id = :buku_id";
        $stmt_buku = oci_parse($conn, $update_buku);
        oci_bind_by_name($stmt_buku, ":buku_id", $buku_id);

        if (!oci_execute($stmt_buku)) {
            throw new Exception("Gagal memperbarui stok buku");
        }

        // Commit transaksi
        oci_commit($conn);
        $_SESSION['success'] = "Buku berhasil dikembalikan" . ($denda > 0 ? " dengan denda Rp " . number_format($denda, 0, ',', '.') : "");

    } catch (Exception $e) {
        // Rollback jika terjadi kesalahan
        oci_rollback($conn);
        $_SESSION['error'] = "Gagal memproses pengembalian: " . $e->getMessage();
    }

    header("Location: peminjaman.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengembalian Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Pengembalian Buku</h2>
            <a href="peminjaman.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
        
        <div class="card shadow">
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Judul Buku</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($peminjaman['JUDUL']) ?>" readonly>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Tanggal Pinjam</label>
                            <input type="text" class="form-control" value="<?= date('d/m/Y', strtotime($peminjaman['TANGGAL_PINJAM'])) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Batas Kembali</label>
                            <input type="text" class="form-control <?= $terlambat ? 'text-danger' : '' ?>" 
                                   value="<?= date('d/m/Y', strtotime($peminjaman['TANGGAL_KEMBALI'])) ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tanggal Kembali</label>
                        <input type="text" class="form-control" value="<?= date('d/m/Y') ?>" readonly>
                    </div>
                    
                    <?php if ($terlambat): ?>
                    <div class="alert alert-warning">
                        <h5 class="alert-heading">Terlambat!</h5>
                        <p class="mb-0">
                            Keterlambatan: <?= $hari_terlambat ?> hari<br>
                            Denda: Rp <?= number_format($denda, 0, ',', '.') ?> (Rp 5.000 per hari)
                        </p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-check-circle"></i> Konfirmasi Pengembalian
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>