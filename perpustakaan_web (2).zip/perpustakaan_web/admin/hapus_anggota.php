<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: anggota.php");
    exit();
}

$id = (int)$_GET['id'];

// Dapatkan koneksi Oracle
global $conn;

// Ambil user_id dari anggota
$query = "SELECT user_id FROM anggota WHERE id = :id";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id", $id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    $_SESSION['error'] = "Query error: " . htmlentities($e['message']);
    header("Location: anggota.php");
    exit();
}

$row = oci_fetch_assoc($stmt);
oci_free_statement($stmt);

if (!$row) {
    header("Location: anggota.php");
    exit();
}

$user_id = $row['USER_ID'];

// Hapus data (gunakan transaksi Oracle)
try {
    // Nonaktifkan autocommit
    oci_execute($conn, OCI_NO_AUTO_COMMIT);

    // Hapus dari tabel anggota
    $delete_anggota = "DELETE FROM anggota WHERE id = :id";
    $stmt_anggota = oci_parse($conn, $delete_anggota);
    oci_bind_by_name($stmt_anggota, ":id", $id);

    if (!oci_execute($stmt_anggota)) {
        throw new Exception("Gagal menghapus anggota");
    }

    // Hapus dari tabel users
    $delete_user = "DELETE FROM users WHERE id = :user_id";
    $stmt_user = oci_parse($conn, $delete_user);
    oci_bind_by_name($stmt_user, ":user_id", $user_id);

    if (!oci_execute($stmt_user)) {
        throw new Exception("Gagal menghapus pengguna");
    }

    // Commit transaksi
    oci_commit($conn);
    $_SESSION['success'] = "Anggota berhasil dihapus";

} catch (Exception $e) {
    // Rollback jika terjadi kesalahan
    oci_rollback($conn);
    $_SESSION['error'] = "Gagal menghapus anggota: " . $e->getMessage();
}

header("Location: anggota.php");
exit();
?>