<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Search
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';

// Dapatkan koneksi Oracle
global $conn;

// Query anggota
$query = "SELECT a.id, a.nama, a.email, a.telepon, u.username FROM anggota a 
          JOIN users u ON a.user_id = u.id
          WHERE UPPER(a.nama) LIKE '%' || :search || '%' OR UPPER(a.email) LIKE '%' || :search || '%'
          ORDER BY a.nama ASC OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";

$stmt = oci_parse($conn, $query);
$search_upper = strtoupper($search); // Oracle case-sensitive
oci_bind_by_name($stmt, ":search", $search_upper);
oci_bind_by_name($stmt, ":offset", $offset);
oci_bind_by_name($stmt, ":limit", $per_page);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$anggota_list = [];
while ($row = oci_fetch_assoc($stmt)) {
    $anggota_list[] = $row;
}
oci_free_statement($stmt);

// Total data untuk pagination
$count_query = "SELECT COUNT(*) as total FROM anggota a 
                WHERE UPPER(a.nama) LIKE '%' || :search_count || '%' OR UPPER(a.email) LIKE '%' || :search_count || '%'";

$stmt_count = oci_parse($conn, $count_query);
oci_bind_by_name($stmt_count, ":search_count", $search_upper);

if (!oci_execute($stmt_count)) {
    $e = oci_error($stmt_count);
    die("Count query error: " . htmlentities($e['message']));
}

$total_row = oci_fetch_assoc($stmt_count);
$total_pages = ceil($total_row['TOTAL'] / $per_page);
oci_free_statement($stmt_count);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Kelola Anggota</h2>
            <a href="tambah_anggota.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Anggota
            </a>
        </div>
        
        <!-- Search Form -->
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari anggota..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-outline-secondary" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
        
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Telepon</th>
                                <th>Username</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($anggota_list as $row): ?>
                            <tr>
                                <td><?= $row['ID'] ?></td>
                                <td><?= htmlspecialchars($row['NAMA']) ?></td>
                                <td><?= htmlspecialchars($row['EMAIL']) ?></td>
                                <td><?= htmlspecialchars($row['TELEPON']) ?></td>
                                <td><?= htmlspecialchars($row['USERNAME']) ?></td>
                                <td>
                                    <a href="edit_anggota.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="hapus_anggota.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>