<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: peminjaman.php");
    exit();
}

$id = (int)$_GET['id'];

// Dapatkan koneksi Oracle
global $conn;

// Ambil detail peminjaman
$query = "SELECT p.*, b.judul, b.isbn, a.nama as nama_anggota, a.email, a.telepon
          FROM peminjaman p
          JOIN buku b ON p.buku_id = b.id
          JOIN anggota a ON p.anggota_id = a.id
          WHERE p.id = :id";

$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id", $id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$peminjaman = oci_fetch_assoc($stmt);

if (!$peminjaman) {
    header("Location: peminjaman.php");
    exit();
}

// Hitung keterlambatan jika masih dipinjam
$terlambat = false;
$hari_terlambat = 0;
$denda = $peminjaman['DENDA'];

$tanggal_kembali = strtotime($peminjaman['TANGGAL_KEMBALI']);
if ($peminjaman['STATUS'] === 'dipinjam' && time() > $tanggal_kembali) {
    $terlambat = true;
    $hari_terlambat = floor((time() - $tanggal_kembali) / (60 * 60 * 24));
    $denda = $hari_terlambat * 5000; // Rp 5.000 per hari
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
    <style>
        .detail-card {
            border-left: 4px solid #0d6efd;
        }
        .status-badge {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Detail Peminjaman</h2>
            <a href="peminjaman.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card detail-card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Informasi Buku</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Judul Buku</label>
                            <p><?= htmlspecialchars($peminjaman['JUDUL']) ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">ISBN</label>
                            <p><?= !empty($peminjaman['ISBN']) ? htmlspecialchars($peminjaman['ISBN']) : '-' ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card detail-card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Informasi Anggota</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama Anggota</label>
                            <p><?= htmlspecialchars($peminjaman['NAMA_ANGGOTA']) ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Kontak</label>
                            <p>
                                Email: <?= htmlspecialchars($peminjaman['EMAIL']) ?><br>
                                Telepon: <?= htmlspecialchars($peminjaman['TELEPON']) ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card detail-card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Detail Transaksi</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Tanggal Pinjam</label>
                        <p><?= date('d/m/Y', strtotime($peminjaman['TANGGAL_PINJAM'])) ?></p>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Batas Kembali</label>
                        <p class="<?= $terlambat ? 'text-danger' : '' ?>">
                            <?= date('d/m/Y', strtotime($peminjaman['TANGGAL_KEMBALI'])) ?>
                            <?= $terlambat ? '<i class="fas fa-exclamation-triangle"></i>' : '' ?>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Status</label>
                        <p>
                            <span class="badge bg-<?= 
                                $peminjaman['STATUS'] === 'dipinjam' ? ($terlambat ? 'danger' : 'warning') : 
                                ($peminjaman['STATUS'] === 'dikembalikan' ? 'success' : 'secondary')
                            ?> status-badge">
                                <?= ucfirst(htmlspecialchars($peminjaman['STATUS'])) ?>
                                <?= $terlambat ? ' (Terlambat)' : '' ?>
                            </span>
                        </p>
                    </div>
                </div>
                
                <?php if ($peminjaman['STATUS'] === 'dikembalikan'): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Tanggal Kembali</label>
                        <p><?= date('d/m/Y', strtotime($peminjaman['TANGGAL_KEMBALI'])) ?></p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Denda</label>
                        <p>Rp <?= number_format((int)$peminjaman['DENDA'], 0, ',', '.') ?></p>
                    </div>
                </div>
                <?php elseif ($terlambat): ?>
                <div class="alert alert-warning">
                    <h5 class="alert-heading">Keterlambatan</h5>
                    <p class="mb-0">
                        Telat: <?= $hari_terlambat ?> hari<br>
                        Perkiraan denda: Rp <?= number_format($denda, 0, ',', '.') ?> (Rp 5.000/hari)
                    </p>
                </div>
                <?php endif; ?>
                
                <?php if ($peminjaman['STATUS'] === 'dipinjam'): ?>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="pengembalian.php?id=<?= $peminjaman['ID'] ?>" class="btn btn-primary">
                        <i class="fas fa-book"></i> Proses Pengembalian
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>