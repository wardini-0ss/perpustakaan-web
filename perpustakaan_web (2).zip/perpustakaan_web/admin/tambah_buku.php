<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

$errors = [];

// Dapatkan koneksi Oracle
global $conn;

// Ambil daftar kategori untuk dropdown
$kategori_result = [];
$kategori_stmt = oci_parse($conn, "SELECT * FROM kategori ORDER BY nama");
if (!oci_execute($kategori_stmt)) {
    $e = oci_error($kategori_stmt);
    die("Kategori query error: " . htmlentities($e['message']));
}

while ($row = oci_fetch_assoc($kategori_stmt)) {
    $kategori_result[] = $row;
}
oci_free_statement($kategori_stmt);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $judul = clean_input($_POST['judul'] ?? '');
    $kategori_id = isset($_POST['kategori_id']) ? (int)$_POST['kategori_id'] : 0;
    $pengarang = clean_input($_POST['pengarang'] ?? '');
    $penerbit = clean_input($_POST['penerbit'] ?? '');
    $tahun_terbit = isset($_POST['tahun_terbit']) ? (int)$_POST['tahun_terbit'] : 0;
    $isbn = clean_input($_POST['isbn'] ?? '');
    $jumlah = isset($_POST['jumlah']) ? (int)$_POST['jumlah'] : 0;
    $deskripsi = clean_input($_POST['deskripsi'] ?? '');
    $cover_url = clean_input($_POST['cover_url'] ?? '');

    // Validasi input
    if (empty($judul)) {
        $errors[] = "Judul buku harus diisi";
    }

    if ($kategori_id > 0) {
        // Validasi kategori exists
        $stmt_kategori = oci_parse($conn, "SELECT id FROM kategori WHERE id = :id");
        oci_bind_by_name($stmt_kategori, ":id", $kategori_id);
        if (!oci_execute($stmt_kategori)) {
            $e = oci_error($stmt_kategori);
            $errors[] = "Gagal memeriksa kategori: " . htmlentities($e['message']);
        } else {
            $row = oci_fetch_assoc($stmt_kategori);
            if (!$row) {
                $errors[] = "Kategori tidak valid";
            }
        }
    }

    if ($tahun_terbit < 1800 || $tahun_terbit > date('Y')) {
        $errors[] = "Tahun terbit tidak valid";
    }

    if ($jumlah < 0) {
        $errors[] = "Jumlah buku tidak valid";
    }

    // Jika tidak ada error, proses penyimpanan
    if (empty($errors)) {
        try {
            // Nonaktifkan autocommit
            oci_execute($conn, OCI_NO_AUTO_COMMIT);

            // Insert ke tabel buku
            $insert_buku = "INSERT INTO buku (
                            judul, 
                            kategori_id, 
                            pengarang, 
                            penerbit, 
                            tahun_terbit, 
                            isbn, 
                            jumlah, 
                            deskripsi,
                            cover_url
                          ) VALUES (
                            :judul, 
                            :kategori_id, 
                            :pengarang, 
                            :penerbit, 
                            :tahun_terbit, 
                            :isbn, 
                            :jumlah, 
                            :deskripsi,
                            :cover_url
                          )";

            $stmt_buku = oci_parse($conn, $insert_buku);
            oci_bind_by_name($stmt_buku, ":judul", $judul);
            oci_bind_by_name($stmt_buku, ":kategori_id", $kategori_id);
            oci_bind_by_name($stmt_buku, ":pengarang", $pengarang);
            oci_bind_by_name($stmt_buku, ":penerbit", $penerbit);
            oci_bind_by_name($stmt_buku, ":tahun_terbit", $tahun_terbit);
            oci_bind_by_name($stmt_buku, ":isbn", $isbn);
            oci_bind_by_name($stmt_buku, ":jumlah", $jumlah);
            oci_bind_by_name($stmt_buku, ":deskripsi", $deskripsi);
            oci_bind_by_name($stmt_buku, ":cover_url", $cover_url);

            if (!oci_execute($stmt_buku)) {
                $e = oci_error($stmt_buku);
                throw new Exception(htmlentities($e['message']));
            }

            // Commit transaksi
            oci_commit($conn);
            $_SESSION['success'] = "Buku berhasil ditambahkan";
            header("Location: buku.php");
            exit();
        } catch (Exception $e) {
            // Rollback jika error
            oci_rollback($conn);
            $errors[] = "Gagal menambahkan buku: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku Baru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> 
    <style>
        .cover-preview {
            max-width: 200px;
            max-height: 300px;
            display: none;
            margin-top: 10px;
        }
        .form-section {
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-book"></i> Tambah Buku Baru</h2>
            <a href="buku.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <!-- Informasi Utama Buku -->
                        <div class="col-md-8">
                            <div class="form-section">
                                <h5 class="mb-3"><i class="fas fa-info-circle"></i> Informasi Buku</h5>
                                <div class="mb-3">
                                    <label for="judul" class="form-label">Judul Buku <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="judul" name="judul" value="<?= htmlspecialchars($judul ?? '') ?>" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="pengarang" class="form-label">Pengarang</label>
                                        <input type="text" class="form-control" id="pengarang" name="pengarang" value="<?= htmlspecialchars($pengarang ?? '') ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="penerbit" class="form-label">Penerbit</label>
                                        <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?= htmlspecialchars($penerbit ?? '') ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                                        <input type="number" class="form-control" id="tahun_terbit" name="tahun_terbit"
                                               min="1800" max="<?= date('Y') ?>" value="<?= date('Y') ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="isbn" class="form-label">ISBN</label>
                                        <input type="text" class="form-control" id="isbn" name="isbn" value="<?= htmlspecialchars($isbn ?? '') ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="kategori_id" class="form-label">Kategori</label>
                                    <select class="form-select" id="kategori_id" name="kategori_id">
                                        <option value="0">-- Pilih Kategori --</option>
                                        <?php foreach ($kategori_result as $kategori): ?>
                                            <option value="<?= $kategori['ID'] ?>" <?= $kategori_id == $kategori['ID'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($kategori['NAMA']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="jumlah" class="form-label">Jumlah Stok</label>
                                    <input type="number" class="form-control" id="jumlah" name="jumlah" min="0" value="1">
                                </div>
                            </div>

                            <div class="form-section">
                                <h5 class="mb-3"><i class="fas fa-align-left"></i> Deskripsi</h5>
                                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="5"><?= htmlspecialchars($deskripsi ?? '') ?></textarea>
                            </div>
                        </div>

                        <!-- Cover Buku -->
                        <div class="col-md-4">
                            <div class="form-section">
                                <h5 class="mb-3"><i class="fas fa-image"></i> Cover Buku</h5>
                                <div class="mb-3">
                                    <label for="cover_url" class="form-label">URL Gambar Cover</label>
                                    <input type="url" class="form-control" id="cover_url" name="cover_url"
                                           placeholder="https://example.com/cover.jpg"> 
                                    <small class="text-muted">Atau upload gambar cover</small>
                                </div>
                                <div class="mb-3">
                                    <label for="cover_upload" class="form-label">Upload Cover</label>
                                    <input type="file" class="form-control" id="cover_upload" accept="image/*">
                                    <small class="text-muted">Maksimal 2MB (JPG/PNG)</small>
                                </div>
                                <div class="text-center">
                                    <img id="cover_preview" class="img-thumbnail cover-preview" alt="Preview Cover">
                                    <div id="no_cover" class="text-muted p-4 border rounded">
                                        <i class="fas fa-book fa-4x mb-2"></i>
                                        <p>Tidak ada cover</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <button type="reset" class="btn btn-outline-secondary me-md-2">
                            <i class="fas fa-undo"></i> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Simpan Buku
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
    <script>
        // Preview cover image
        document.getElementById('cover_upload').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    const preview = document.getElementById('cover_preview');
                    preview.src = event.target.result;
                    preview.style.display = 'block';
                    document.getElementById('no_cover').style.display = 'none';
                };
                reader.readAsDataURL(file);
            }
        });

        // Preview dari URL
        document.getElementById('cover_url').addEventListener('change', function() {
            const url = this.value;
            if (url) {
                const preview = document.getElementById('cover_preview');
                preview.src = url;
                preview.style.display = 'block';
                document.getElementById('no_cover').style.display = 'none';
            }
        });
    </script>
</body>
</html>