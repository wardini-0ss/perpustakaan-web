<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: anggota.php");
    exit();
}

$id = (int)$_GET['id'];
$errors = [];

// Dapatkan koneksi Oracle
global $conn;

// Ambil data anggota
$query = "SELECT a.*, u.username, u.id as user_id FROM anggota a 
          JOIN users u ON a.user_id = u.id 
          WHERE a.id = :id";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id", $id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$anggota = oci_fetch_assoc($stmt);

if (!$anggota) {
    header("Location: anggota.php");
    exit();
}

function oci8_get_string($value) {
    if ($value instanceof OCILob) {
        return (string)$value->read(4096);
    }
    return (string)$value;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Baca semua input POST
    $nama = clean_input($_POST['nama'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $alamat = clean_input($_POST['alamat'] ?? '');
    $telepon = clean_input($_POST['telepon'] ?? '');
    $username = clean_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validasi input
    if (empty($nama)) $errors[] = "Nama harus diisi";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email tidak valid";
    if (empty($username)) $errors[] = "Username harus diisi";

    // Cek username unik
    if ($username !== $anggota['USERNAME']) {
        $check_query = "SELECT COUNT(*) AS total FROM users WHERE username = :username";
        $check_stmt = oci_parse($conn, $check_query);
        oci_bind_by_name($check_stmt, ":username", $username);
        if (!oci_execute($check_stmt)) {
            $e = oci_error($check_stmt);
            $errors[] = "Gagal memeriksa username: " . htmlentities($e['message']);
        } else {
            $row = oci_fetch_assoc($check_stmt);
            if ((int)$row['TOTAL'] > 0) {
                $errors[] = "Username sudah digunakan";
            }
        }
    }

    // Validasi password
    if (!empty($password) && strlen($password) < 6) {
        $errors[] = "Password minimal 6 karakter";
    }

    if (empty($errors)) {
        try {
            // Update tabel users
            $user_update = "UPDATE users SET username = :username";
            $params = [":username" => $username];
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $user_update .= ", password = :password";
                $params[":password"] = $hashed_password;
            }
            $user_update .= " WHERE id = :user_id";
            $params[":user_id"] = $anggota['USER_ID'];

            $stmt_user = oci_parse($conn, $user_update);
            foreach ($params as $key => $value) {
                oci_bind_by_name($stmt_user, $key, $params[$key]);
            }

            if (!oci_execute($stmt_user)) {
                $e = oci_error($stmt_user);
                throw new Exception(htmlentities($e['message']));
            }

            // Update tabel anggota
            $stmt_anggota = oci_parse($conn, "
                UPDATE anggota 
                SET nama = :nama, alamat = :alamat, email = :email, telepon = :telepon 
                WHERE id = :id
            ");
            oci_bind_by_name($stmt_anggota, ":nama", $nama);
            oci_bind_by_name($stmt_anggota, ":alamat", $alamat);
            oci_bind_by_name($stmt_anggota, ":email", $email);
            oci_bind_by_name($stmt_anggota, ":telepon", $telepon);
            oci_bind_by_name($stmt_anggota, ":id", $id);

            if (!oci_execute($stmt_anggota)) {
                $e = oci_error($stmt_anggota);
                throw new Exception(htmlentities($e['message']));
            }

            oci_commit($conn);
            $_SESSION['success'] = "Data berhasil diperbarui";
            header("Location: anggota.php");
            exit();
        } catch (Exception $e) {
            oci_rollback($conn);
            $errors[] = "Gagal memperbarui data: " . $e->getMessage();
        }
    }
}

// Ambil data untuk tampilan
$nama     = oci8_get_string($anggota['NAMA']);
$email    = oci8_get_string($anggota['EMAIL']);
$alamat   = oci8_get_string($anggota['ALAMAT']);
$telepon  = oci8_get_string($anggota['TELEPON']);
$username = oci8_get_string($anggota['USERNAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">       
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Anggota</h2>
            <a href="anggota.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="nama" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama" name="nama"
                                   value="<?= htmlspecialchars($nama, ENT_QUOTES, 'UTF-8') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                   value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="2"><?= htmlspecialchars($alamat, ENT_QUOTES, 'UTF-8') ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="telepon" class="form-label">Telepon</label>
                            <input type="tel" class="form-control" id="telepon" name="telepon"
                                   value="<?= htmlspecialchars($telepon, ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username"
                                   value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="password" class="form-label">Password Baru (kosongkan jika tidak diubah)</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>