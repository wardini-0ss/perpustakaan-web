<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

// Pagination dan Pencarian
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$kategori = isset($_GET['kategori']) ? (int)$_GET['kategori'] : 0;

// Query buku
$query = "SELECT b.*, k.nama as kategori FROM buku b 
          LEFT JOIN kategori k ON b.kategori_id = k.id
          WHERE (b.judul LIKE '%' || :search || '%' OR b.pengarang LIKE '%' || :search || '%' OR b.penerbit LIKE '%' || :search || '%')";

if ($kategori > 0) {
    $query .= " AND b.kategori_id = :kategori";
}

$query .= " ORDER BY b.judul ASC OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";

$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":search", $search);
if ($kategori > 0) {
    oci_bind_by_name($stmt, ":kategori", $kategori);
}
oci_bind_by_name($stmt, ":offset", $offset);
oci_bind_by_name($stmt, ":limit", $per_page);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$buku = [];
while ($row = oci_fetch_assoc($stmt)) {
    $buku[] = $row;
}
oci_free_statement($stmt);

// Total data
$count_query = "SELECT COUNT(*) as total FROM buku b 
                WHERE (b.judul LIKE '%' || :search_count || '%' OR b.pengarang LIKE '%' || :search_count || '%' OR b.penerbit LIKE '%' || :search_count || '%')";

if ($kategori > 0) {
    $count_query .= " AND b.kategori_id = :kategori_count";
}

$count_stmt = oci_parse($conn, $count_query);
oci_bind_by_name($count_stmt, ":search_count", $search);
if ($kategori > 0) {
    oci_bind_by_name($count_stmt, ":kategori_count", $kategori);
}

if (!oci_execute($count_stmt)) {
    $e = oci_error($count_stmt);
    die("Count query error: " . htmlentities($e['message']));
}

$total_row = oci_fetch_assoc($count_stmt);
$total_pages = ceil($total_row['TOTAL'] / $per_page);
oci_free_statement($count_stmt);

// Daftar kategori
$kategori_result = [];
$kategori_stmt = oci_parse($conn, "SELECT * FROM kategori ORDER BY nama");
if (!oci_execute($kategori_stmt)) {
    $e = oci_error($kategori_stmt);
    die("Kategori query error: " . htmlentities($e['message']));
}

while ($row = oci_fetch_assoc($kategori_stmt)) {
    $kategori_result[] = $row;
}
oci_free_statement($kategori_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Kelola Buku</h2>
            <div>
                <a href="tambah_buku.php" class="btn btn-primary me-2">
                    <i class="fas fa-plus"></i> Tambah Buku
                </a>
                <a href="tambah_kategori.php" class="btn btn-outline-secondary">
                    <i class="fas fa-tags"></i> Kelola Kategori
                </a>
            </div>
        </div>
        
        <!-- Search Form -->
        <form method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Cari buku..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-4">
                    <select name="kategori" class="form-select">
                        <option value="0">Semua Kategori</option>
                        <?php foreach ($kategori_result as $cat): ?>
                        <option value="<?= $cat['ID'] ?>" <?= $kategori == $cat['ID'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['NAMA']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
        </form>
        
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Cover</th>
                                <th>Judul</th>
                                <th>Pengarang</th>
                                <th>Kategori</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($buku as $row): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($row['COVER_URL'])): ?>
                                        <img src="<?= htmlspecialchars($row['COVER_URL']) ?>" style="width:50px;height:70px;object-fit:cover">
                                    <?php else: ?>
                                        <i class="fas fa-book fa-2x text-secondary"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['JUDUL']) ?></td>
                                <td><?= htmlspecialchars($row['PENGARANG']) ?></td>
                                <td><?= htmlspecialchars($row['KATEGORI'] ?? '-') ?></td>
                                <td><?= $row['JUMLAH'] ?></td>
                                <td>
                                    <a href="edit_buku.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="hapus_buku.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>&kategori=<?= $kategori ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&kategori=<?= $kategori ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>&kategori=<?= $kategori ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
    <script>
        // Auto submit kategori filter
        document.querySelector('select[name="kategori"]').addEventListener('change', function() {
            this.form.submit();
        });
    </script>
</body>
</html>