<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit();
}

$id = (int)$_GET['id'];
$errors = [];

// Dapatkan koneksi Oracle
global $conn;

// Ambil data buku
$query = "SELECT * FROM buku WHERE id = :id";
$stmt = oci_parse($conn, $query);
oci_bind_by_name($stmt, ":id", $id);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$buku = oci_fetch_assoc($stmt);

if (!$buku) {
    header("Location: buku.php");
    exit();
}

// Ambil daftar kategori
$kategori_result = [];
$kategori_stmt = oci_parse($conn, "SELECT * FROM kategori ORDER BY nama");
if (!oci_execute($kategori_stmt)) {
    $e = oci_error($kategori_stmt);
    die("Kategori query error: " . htmlentities($e['message']));
}

while ($row = oci_fetch_assoc($kategori_stmt)) {
    $kategori_result[] = $row;
}
oci_free_statement($kategori_stmt);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = clean_input($_POST['judul'] ?? '');
    $kategori_id = (int)($_POST['kategori_id'] ?? 0);
    $pengarang = clean_input($_POST['pengarang'] ?? '');
    $penerbit = clean_input($_POST['penerbit'] ?? '');
    $tahun_terbit = (int)($_POST['tahun_terbit'] ?? 0);
    $isbn = clean_input($_POST['isbn'] ?? '');
    $jumlah = (int)($_POST['jumlah'] ?? 0);
    $deskripsi = clean_input($_POST['deskripsi'] ?? '');

    // Validasi input
    if (empty($judul)) $errors[] = "Judul harus diisi";

    if ($kategori_id > 0) {
        $check_kategori = "SELECT id FROM kategori WHERE id = :kategori_id";
        $stmt_kategori = oci_parse($conn, $check_kategori);
        oci_bind_by_name($stmt_kategori, ":kategori_id", $kategori_id);
        if (!oci_execute($stmt_kategori)) {
            $e = oci_error($stmt_kategori);
            $errors[] = "Gagal memeriksa kategori: " . htmlentities($e['message']);
        } else {
            $row = oci_fetch_assoc($stmt_kategori);
            if (!$row) {
                $errors[] = "Kategori tidak valid";
            }
        }
    }

    if ($jumlah < 0) $errors[] = "Jumlah tidak valid";

    if (empty($errors)) {
        try {
            // Proses upload gambar cover
            // Ubah kode upload menjadi:
$upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/cover/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$file_name = uniqid() . '_' . basename($_FILES["cover_url"]["name"]);
$target_file = $upload_dir . $file_name;

if (move_uploaded_file($_FILES["cover_url"]["tmp_name"], $target_file)) {
    $cover_url = '/uploads/cover/' . $file_name; // Gunakan path relatif root
}

            // Update buku
            $update_query = "UPDATE buku SET 
                             judul = :judul, 
                             kategori_id = :kategori_id, 
                             pengarang = :pengarang, 
                             penerbit = :penerbit,
                             tahun_terbit = :tahun_terbit,
                             isbn = :isbn,
                             jumlah = :jumlah,
                             deskripsi = :deskripsi,
                             cover_url = :cover_url
                             WHERE id = :id";

            $stmt_update = oci_parse($conn, $update_query);
            oci_bind_by_name($stmt_update, ":judul", $judul);
            oci_bind_by_name($stmt_update, ":kategori_id", $kategori_id);
            oci_bind_by_name($stmt_update, ":pengarang", $pengarang);
            oci_bind_by_name($stmt_update, ":penerbit", $penerbit);
            oci_bind_by_name($stmt_update, ":tahun_terbit", $tahun_terbit);
            oci_bind_by_name($stmt_update, ":isbn", $isbn);
            oci_bind_by_name($stmt_update, ":jumlah", $jumlah);
            oci_bind_by_name($stmt_update, ":deskripsi", $deskripsi);
            oci_bind_by_name($stmt_update, ":cover_url", $cover_url);
            oci_bind_by_name($stmt_update, ":id", $id);

            if (oci_execute($stmt_update) && oci_commit($conn)) {
                $_SESSION['success'] = "Data buku berhasil diperbarui";
                header("Location: buku.php");
                exit();
            } else {
                $e = oci_error($stmt_update);
                $errors[] = "Gagal memperbarui buku: " . htmlentities($e['message']);
            }
        } catch (Exception $e) {
            oci_rollback($conn);
            $errors[] = "Gagal memperbarui data: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> 
    <style>
        .cover-preview {
            max-width: 200px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Buku</h2>
            <a href="buku.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="card shadow">
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="judul" class="form-label">Judul Buku</label>
                            <input type="text" class="form-control" id="judul" name="judul" value="<?= htmlspecialchars($buku['JUDUL']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="kategori_id" class="form-label">Kategori</label>
                            <select class="form-select" id="kategori_id" name="kategori_id">
                                <option value="0">-- Pilih Kategori --</option>
                                <?php foreach ($kategori_result as $row): ?>
                                    <option value="<?= $row['ID'] ?>" <?= $row['ID'] == $buku['KATEGORI_ID'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($row['NAMA']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="pengarang" class="form-label">Pengarang</label>
                            <input type="text" class="form-control" id="pengarang" name="pengarang" value="<?= htmlspecialchars($buku['PENGARANG']) ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="penerbit" class="form-label">Penerbit</label>
                            <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?= htmlspecialchars($buku['PENERBIT']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                            <input type="number" class="form-control" id="tahun_terbit" name="tahun_terbit" min="1900" max="<?= date('Y') ?>" value="<?= $buku['TAHUN_TERBIT'] ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="isbn" class="form-label">ISBN</label>
                            <input type="text" class="form-control" id="isbn" name="isbn" value="<?= htmlspecialchars($buku['ISBN']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah" min="0" value="<?= $buku['JUMLAH'] ?>">
                        </div>
                        <div class="col-12">
                            <label for="deskripsi" class="form-label">Deskripsi</label>
                            <?php 
                            $deskripsi = $buku['DESKRIPSI'];
                            if ($deskripsi instanceof OCILob) {
                                $deskripsi = $deskripsi->read(4096); // Baca maksimal 4096 karakter
                            }
                            ?>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?= htmlspecialchars((string)$deskripsi) ?></textarea>
                        </div>
                        <div class="col-12">
                            <label for="cover_url" class="form-label">Cover Buku</label>
                            <input type="file" class="form-control" id="cover_url" name="cover_url">
                            <?php if (!empty($buku['COVER_URL'])): ?>
                                <img src="<?= htmlspecialchars($buku['COVER_URL']) ?>" alt="Cover Buku" class="mt-2 img-fluid cover-preview">
                            <?php endif; ?>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>