<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = clean_input($_POST['nama'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $alamat = clean_input($_POST['alamat'] ?? '');
    $telepon = clean_input($_POST['telepon'] ?? '');
    $username = clean_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Validasi
    if (empty($nama)) $errors[] = "Nama harus diisi";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email tidak valid";
    if (empty($username)) $errors[] = "Username harus diisi";
    if (strlen($password) < 6) $errors[] = "Password minimal 6 karakter";
    if ($password !== $password_confirm) $errors[] = "Konfirmasi password tidak sama";

    // Cek username sudah ada
    if (is_username_exists($conn, $username)) {
        $errors[] = "Username sudah digunakan";
    }

    if (empty($errors)) {
        try {
            // Dapatkan koneksi Oracle
            global $conn;

            // Nonaktifkan autocommit
            oci_execute($conn, OCI_NO_AUTO_COMMIT);

            // Insert ke tabel users
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $insert_user = "INSERT INTO users (username, password, role) VALUES (:username, :password, 'anggota')";
            $stmt_user = oci_parse($conn, $insert_user);
            oci_bind_by_name($stmt_user, ":username", $username);
            oci_bind_by_name($stmt_user, ":password", $hashed_password);

            if (!oci_execute($stmt_user)) {
                $e = oci_error($stmt_user);
                throw new Exception(htmlentities($e['message']));
            }

            // Ambil user_id terakhir (misalnya pakai sequence)
            $user_id = null;
            $seq_query = "SELECT users_seq.CURRVAL FROM dual"; // Pastikan sequence bernama users_seq
            $stmt_seq = oci_parse($conn, $seq_query);
            if (!oci_execute($stmt_seq)) {
                $e = oci_error($stmt_seq);
                throw new Exception("Gagal ambil ID pengguna: " . htmlentities($e['message']));
            }
            $row = oci_fetch_assoc($stmt_seq);
            $user_id = $row['CURRVAL'];

            // Insert ke tabel anggota
            $insert_anggota = "INSERT INTO anggota (user_id, nama, alamat, email, telepon) 
                              VALUES (:user_id, :nama, :alamat, :email, :telepon)";
            $stmt_anggota = oci_parse($conn, $insert_anggota);
            oci_bind_by_name($stmt_anggota, ":user_id", $user_id);
            oci_bind_by_name($stmt_anggota, ":nama", $nama);
            oci_bind_by_name($stmt_anggota, ":alamat", $alamat);
            oci_bind_by_name($stmt_anggota, ":email", $email);
            oci_bind_by_name($stmt_anggota, ":telepon", $telepon);

            if (!oci_execute($stmt_anggota)) {
                $e = oci_error($stmt_anggota);
                throw new Exception(htmlentities($e['message']));
            }

            // Commit transaksi
            oci_commit($conn);
            $_SESSION['success'] = "Anggota baru berhasil ditambahkan";
            header("Location: anggota.php");
            exit();
        } catch (Exception $e) {
            // Rollback jika error
            oci_rollback($conn);
            $errors[] = "Gagal menambahkan anggota: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Tambah Anggota Baru</h2>
            <a href="anggota.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="card shadow">
            <div class="card-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="nama" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= htmlspecialchars($nama ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="2"><?= htmlspecialchars($alamat ?? '') ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="telepon" class="form-label">Telepon</label>
                            <input type="tel" class="form-control" id="telepon" name="telepon" value="<?= htmlspecialchars($telepon ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($username ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="col-md-6">
                            <label for="password_confirm" class="form-label">Konfirmasi Password</label>
                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-save"></i> Simpan
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>