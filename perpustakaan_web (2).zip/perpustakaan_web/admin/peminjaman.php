<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

// Filter dan Pagination
$status = isset($_GET['status']) ? clean_input($_GET['status']) : 'semua';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Dapatkan koneksi Oracle
global $conn;

// Query peminjaman
$query = "SELECT p.*, b.judul, b.isbn, a.nama as nama_anggota 
          FROM peminjaman p
          JOIN buku b ON p.buku_id = b.id
          JOIN anggota a ON p.anggota_id = a.id";

if ($status !== 'semua') {
    if ($status === 'terlambat') {
        $query .= " WHERE p.status = 'dipinjam' AND p.tanggal_kembali < SYSDATE";
    } else {
        $query .= " WHERE p.status = :status";
    }
}

$query .= " ORDER BY p.tanggal_pinjam DESC OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";

$stmt = oci_parse($conn, $query);

if ($status !== 'semua') {
    if ($status === 'terlambat') {
        // Status terlambat sudah di-filter dalam WHERE
    } else {
        oci_bind_by_name($stmt, ":status", $status);
    }
}
oci_bind_by_name($stmt, ":offset", $offset);
oci_bind_by_name($stmt, ":limit", $per_page);

if (!oci_execute($stmt)) {
    $e = oci_error($stmt);
    die("Query error: " . htmlentities($e['message']));
}

$peminjaman_list = [];
while ($row = oci_fetch_assoc($stmt)) {
    $peminjaman_list[] = $row;
}
oci_free_statement($stmt);

// Total data
$count_query = "SELECT COUNT(*) AS total FROM peminjaman p
                WHERE 1=1"; // Dummy WHERE agar mudah tambah kondisi

if ($status !== 'semua') {
    if ($status === 'terlambat') {
        $count_query .= " AND p.status = 'dipinjam' AND p.tanggal_kembali < SYSDATE";
    } else {
        $count_query .= " AND p.status = :status_count";
    }
}

$stmt_count = oci_parse($conn, $count_query);

if ($status !== 'semua' && $status !== 'terlambat') {
    oci_bind_by_name($stmt_count, ":status_count", $status);
}

if (!oci_execute($stmt_count)) {
    $e = oci_error($stmt_count);
    die("Count query error: " . htmlentities($e['message']));
}

$total_row = oci_fetch_assoc($stmt_count);
$total_pages = ceil($total_row['TOTAL'] / $per_page);
oci_free_statement($stmt_count);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <h2 class="mb-4">Kelola Peminjaman</h2>
        
        <!-- Filter Status -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="semua" <?= $status === 'semua' ? 'selected' : '' ?>>Semua Status</option>
                            <option value="dipinjam" <?= $status === 'dipinjam' ? 'selected' : '' ?>>Dipinjam</option>
                            <option value="dikembalikan" <?= $status === 'dikembalikan' ? 'selected' : '' ?>>Dikembalikan</option>
                            <option value="terlambat" <?= $status === 'terlambat' ? 'selected' : '' ?>>Terlambat</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Filter</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Judul Buku</th>
                                <th>Anggota</th>
                                <th>Tanggal Pinjam</th>
                                <th>Batas Kembali</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($peminjaman_list as $row): 
                                $tanggal_kembali = strtotime($row['TANGGAL_KEMBALI']);
                                $today = strtotime(date('Y-m-d'));
                                $terlambat = ($row['STATUS'] === 'dipinjam') && ($tanggal_kembali < $today);
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($row['ID']) ?></td>
                                <td><?= htmlspecialchars($row['JUDUL']) ?></td>
                                <td><?= htmlspecialchars($row['NAMA_ANGGOTA']) ?></td>
                                <td><?= date('d/m/Y', strtotime($row['TANGGAL_PINJAM'])) ?></td>
                                <td class="<?= $terlambat ? 'text-danger' : '' ?>">
                                    <?= date('d/m/Y', strtotime($row['TANGGAL_KEMBALI'])) ?>
                                    <?= $terlambat ? '<i class="fas fa-exclamation-triangle"></i>' : '' ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $row['STATUS'] === 'dipinjam' ? ($terlambat ? 'danger' : 'warning') : 
                                        ($row['STATUS'] === 'dikembalikan' ? 'success' : 'secondary')
                                    ?>">
                                        <?= ucfirst(htmlspecialchars($row['STATUS'])) ?>
                                        <?= $terlambat ? ' (Terlambat)' : '' ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['STATUS'] === 'dipinjam'): ?>
                                    <a href="pengembalian.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-success">
                                        <i class="fas fa-book"></i> Proses Kembali
                                    </a>
                                    <?php endif; ?>
                                    <a href="detail_peminjaman.php?id=<?= $row['ID'] ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-info-circle"></i> Detail
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page-1 ?>&status=<?= urlencode($status) ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&status=<?= urlencode($status) ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page+1 ?>&status=<?= urlencode($status) ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>