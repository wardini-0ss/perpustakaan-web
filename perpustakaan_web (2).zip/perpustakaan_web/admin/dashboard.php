<?php
require_once '../includes/auth.php';
redirectIfNotAdmin();

// Dapatkan koneksi Oracle dari auth.php
global $conn;

// Error reporting untuk development
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --success-color: #1cc88a;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-bg: #f8f9fc;
        }
        
        body {
            background-color: var(--light-bg);
            font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
        }
        
        .card-header {
            font-weight: 700;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .bg-primary {
            background-color: var(--primary-color) !important;
        }
        
        .bg-success {
            background-color: var(--success-color) !important;
        }
        
        .bg-warning {
            background-color: var(--warning-color) !important;
        }
        
        .display-4 {
            font-weight: 700;
        }
        
        .container {
            padding-top: 2rem;
        }
        
        h2 {
            color: #5a5c69;
            font-weight: 700;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 10px;
        }
        
        h2::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 3px;
            background: var(--primary-color);
        }
        
        .btn-light {
            background-color: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.3);
            color: white;
            font-weight: 600;
        }
        
        .btn-light:hover {
            background-color: rgba(255, 255, 255, 0.3);
            color: white;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .card-title {
            font-size: 1rem;
            opacity: 0.8;
            margin-bottom: 0.5rem;
        }
        
        .card-text {
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <h2><i class="fas fa-tachometer-alt me-2"></i>Dashboard Admin</h2>
        <div class="row mt-4">
            <!-- Card Total Buku -->
            <div class="col-md-4">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header"><i class="fas fa-book me-2"></i>Buku</div>
                    <div class="card-body">
                        <h5 class="card-title">Total Buku</h5>
                        <?php
                        $query = "SELECT COUNT(*) AS TOTAL FROM BUKU";
                        $stmt = oci_parse($conn, $query);
                        
                        if (!$stmt) {
                            $e = oci_error($conn);
                            echo "<p class='card-text display-4'>Error</p>";
                            error_log("Oracle parse error: " . $e['message']);
                        } else {
                            $result = oci_execute($stmt);
                            if (!$result) {
                                $e = oci_error($stmt);
                                echo "<p class='card-text display-4'>Error</p>";
                                error_log("Oracle execute error: " . $e['message']);
                            } else {
                                $row = oci_fetch_assoc($stmt);
                                echo "<p class='card-text display-4'>" . $row['TOTAL'] . "</p>";
                            }
                            oci_free_statement($stmt);
                        }
                        ?>
                        <a href="buku.php" class="btn btn-light"><i class="fas fa-arrow-right me-1"></i>Kelola Buku</a>
                    </div>
                </div>
            </div>
            
            <!-- Card Total Anggota -->
            <div class="col-md-4">
                <div class="card text-white bg-success mb-3">
                    <div class="card-header"><i class="fas fa-users me-2"></i>Anggota</div>
                    <div class="card-body">
                        <h5 class="card-title">Total Anggota</h5>
                        <?php
                        $query = "SELECT COUNT(*) AS TOTAL FROM ANGGOTA";
                        $stmt = oci_parse($conn, $query);
                        
                        if (!$stmt) {
                            $e = oci_error($conn);
                            echo "<p class='card-text display-4'>Error</p>";
                        } else {
                            $result = oci_execute($stmt);
                            if (!$result) {
                                $e = oci_error($stmt);
                                echo "<p class='card-text display-4'>Error</p>";
                            } else {
                                $row = oci_fetch_assoc($stmt);
                                echo "<p class='card-text display-4'>" . $row['TOTAL'] . "</p>";
                            }
                            oci_free_statement($stmt);
                        }
                        ?>
                        <a href="anggota.php" class="btn btn-light"><i class="fas fa-arrow-right me-1"></i>Kelola Anggota</a>
                    </div>
                </div>
            </div>
            
            <!-- Card Peminjaman Aktif -->
            <div class="col-md-4">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header"><i class="fas fa-exchange-alt me-2"></i>Peminjaman</div>
                    <div class="card-body">
                        <h5 class="card-title">Peminjaman Aktif</h5>
                        <?php
                        $query = "SELECT COUNT(*) AS TOTAL FROM PEMINJAMAN WHERE STATUS = 'dipinjam'";
                        $stmt = oci_parse($conn, $query);
                        
                        if (!$stmt) {
                            $e = oci_error($conn);
                            echo "<p class='card-text display-4'>Error</p>";
                        } else {
                            $result = oci_execute($stmt);
                            if (!$result) {
                                $e = oci_error($stmt);
                                echo "<p class='card-text display-4'>Error</p>";
                            } else {
                                $row = oci_fetch_assoc($stmt);
                                echo "<p class='card-text display-4'>" . $row['TOTAL'] . "</p>";
                            }
                            oci_free_statement($stmt);
                        }
                        ?>
                        <a href="peminjaman.php" class="btn btn-light"><i class="fas fa-arrow-right me-1"></i>Kelola Peminjaman</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>