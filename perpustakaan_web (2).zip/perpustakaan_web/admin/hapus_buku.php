<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit();
}

$id = (int)$_GET['id'];

// Dapatkan koneksi Oracle
global $conn;

// Cek apakah buku ada
$check_query = "SELECT id FROM buku WHERE id = :id";
$check_stmt = oci_parse($conn, $check_query);
oci_bind_by_name($check_stmt, ":id", $id);

if (!oci_execute($check_stmt)) {
    $e = oci_error($check_stmt);
    $_SESSION['error'] = "Query error: " . htmlentities($e['message']);
    header("Location: buku.php");
    exit();
}

$row = oci_fetch_assoc($check_stmt);
if (!$row) {
    header("Location: buku.php");
    exit();
}

// Hapus buku
$delete_query = "DELETE FROM buku WHERE id = :id";
$delete_stmt = oci_parse($conn, $delete_query);
oci_bind_by_name($delete_stmt, ":id", $id);

if (oci_execute($delete_stmt) && oci_commit($conn)) {
    $_SESSION['success'] = "Buku berhasil dihapus";
} else {
    $e = oci_error($delete_stmt);
    oci_rollback($conn);
    $_SESSION['error'] = "Gagal menghapus buku: " . htmlentities($e['message']);
}

header("Location: buku.php");
exit();
?>