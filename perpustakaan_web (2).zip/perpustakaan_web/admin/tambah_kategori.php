<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = clean_input($_POST['nama'] ?? '');
    $deskripsi = clean_input($_POST['deskripsi'] ?? '');

    if (empty($nama)) {
        $errors[] = "Nama kategori harus diisi";
    }

    if (empty($errors)) {
        // Dapatkan koneksi Oracle
        global $conn;

        try {
            // Insert ke tabel kategori
            $insert_query = "INSERT INTO kategori (id, nama, deskripsi) VALUES (kategori_seq.NEXTVAL, :nama, :deskripsi)";
            $stmt = oci_parse($conn, $insert_query);
            oci_bind_by_name($stmt, ":nama", $nama);
            oci_bind_by_name($stmt, ":deskripsi", $deskripsi);

            if (!oci_execute($stmt)) {
                $e = oci_error($stmt);
                throw new Exception(htmlentities($e['message']));
            }

            // Commit transaksi
            oci_commit($conn);
            $_SESSION['success'] = "Kategori berhasil ditambahkan";
            header("Location: buku.php");
            exit();
        } catch (Exception $e) {
            // Rollback jika error
            oci_rollback($conn);
            $errors[] = "Gagal menambahkan kategori: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">   
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Tambah Kategori Buku</h2>
            <a href="buku.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="card shadow">
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Kategori</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?= htmlspecialchars($nama ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?= htmlspecialchars($deskripsi ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>   
</body>
</html>