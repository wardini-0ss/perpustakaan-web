<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
redirectIfNotAdmin();

// Dapatkan koneksi Oracle
global $conn;

// Filter tanggal
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> 
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> 
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-4">
        <h2 class="mb-4">Laporan Perpustakaan</h2>

        <!-- Filter Form -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label for="start_date" class="form-label">Dari Tanggal</label>
                        <input type="date" name="start_date" id="start_date" class="form-control" value="<?= $start_date ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="end_date" class="form-label">Sampai Tanggal</label>
                        <input type="date" name="end_date" id="end_date" class="form-control" value="<?= $end_date ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <a href="laporan.php?export=pdf&start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" class="btn btn-danger w-100">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Statistik -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Peminjaman</h5>
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM peminjaman 
                                 WHERE tanggal_pinjam BETWEEN TO_DATE(:start_date, 'YYYY-MM-DD') AND TO_DATE(:end_date, 'YYYY-MM-DD')";
                        $stmt = oci_parse($conn, $query);
                        oci_bind_by_name($stmt, ":start_date", $start_date);
                        oci_bind_by_name($stmt, ":end_date", $end_date);

                        if (!oci_execute($stmt)) {
                            $e = oci_error($stmt);
                            echo "<p class='card-text display-4'>Error</p>";
                        } else {
                            $result = oci_fetch_assoc($stmt);
                            echo "<p class='card-text display-4'>" . $result['TOTAL'] . "</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Buku Dikembalikan</h5>
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM peminjaman 
                                 WHERE status = 'dikembalikan'
                                 AND tanggal_kembali BETWEEN TO_DATE(:start_date, 'YYYY-MM-DD') AND TO_DATE(:end_date, 'YYYY-MM-DD')";
                        $stmt = oci_parse($conn, $query);
                        oci_bind_by_name($stmt, ":start_date", $start_date);
                        oci_bind_by_name($stmt, ":end_date", $end_date);

                        if (!oci_execute($stmt)) {
                            $e = oci_error($stmt);
                            echo "<p class='card-text display-4'>Error</p>";
                        } else {
                            $result = oci_fetch_assoc($stmt);
                            echo "<p class='card-text display-4'>" . $result['TOTAL'] . "</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Total Denda</h5>
                        <?php
                        $query = "SELECT NVL(SUM(denda), 0) AS total FROM peminjaman 
                                 WHERE denda > 0 
                                 AND tanggal_kembali BETWEEN TO_DATE(:start_date, 'YYYY-MM-DD') AND TO_DATE(:end_date, 'YYYY-MM-DD')";
                        $stmt = oci_parse($conn, $query);
                        oci_bind_by_name($stmt, ":start_date", $start_date);
                        oci_bind_by_name($stmt, ":end_date", $end_date);

                        if (!oci_execute($stmt)) {
                            $e = oci_error($stmt);
                            echo "<p class='card-text display-4'>Error</p>";
                        } else {
                            $result = oci_fetch_assoc($stmt);
                            echo "<p class='card-text display-4'>Rp " . number_format($result['TOTAL'], 0, ',', '.') . "</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daftar Peminjaman Terbaru -->
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">Peminjaman Terakhir</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Judul Buku</th>
                                <th>Anggota</th>
                                <th>Status</th>
                                <th>Denda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT p.*, b.judul, a.nama AS nama_anggota 
                                      FROM (
                                          SELECT p.*, ROWNUM rnum FROM (
                                              SELECT * FROM peminjaman ORDER BY tanggal_pinjam DESC
                                          ) p WHERE ROWNUM <= 5
                                      ) p
                                      JOIN buku b ON p.buku_id = b.id
                                      JOIN anggota a ON p.anggota_id = a.id";
                            $stmt = oci_parse($conn, $query);
                            if (!oci_execute($stmt)) {
                                $e = oci_error($stmt);
                                die("Query error: " . htmlentities($e['message']));
                            }

                            while ($row = oci_fetch_assoc($stmt)):
                            ?>
                            <tr>
                                <td><?= date('d/m/Y', strtotime($row['TANGGAL_PINJAM'])); ?></td>
                                <td><?= htmlspecialchars($row['JUDUL']); ?></td>
                                <td><?= htmlspecialchars($row['NAMA_ANGGOTA']); ?></td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $row['STATUS'] === 'dipinjam' ? 'warning' : 
                                        ($row['STATUS'] === 'dikembalikan' ? 'success' : 'danger')
                                    ?>">
                                        <?= ucfirst(htmlspecialchars($row['STATUS'])) ?>
                                    </span>
                                </td>
                                <td>Rp <?= number_format((int)$row['DENDA'], 0, ',', '.') ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Data untuk grafik
        const ctx = document.getElementById('peminjamanChart').getContext('2d');

        const labels = <?php
            // Generate label berdasarkan rentang tanggal
            $labels = [];
            $current = new DateTime($start_date);
            $end = new DateTime($end_date);
            while ($current <= $end) {
                $labels[] = $current->format('d M');
                $current->modify('+1 day');
            }
            echo json_encode($labels);
        ?>;

        const data = <?php
            $data = array_fill(0, count($labels), 0);
            $query = "SELECT TRUNC(tanggal_pinjam) AS tanggal, COUNT(*) AS jumlah 
                     FROM peminjaman 
                     WHERE tanggal_pinjam BETWEEN TO_DATE(:start_date, 'YYYY-MM-DD') AND TO_DATE(:end_date, 'YYYY-MM-DD')
                     GROUP BY TRUNC(tanggal_pinjam)";
            $stmt = oci_parse($conn, $query);
            oci_bind_by_name($stmt, ":start_date", $start_date);
            oci_bind_by_name($stmt, ":end_date", $end_date);

            if (!oci_execute($stmt)) {
                $e = oci_error($stmt);
                echo json_encode([]);
            } else {
                while ($row = oci_fetch_assoc($stmt)) {
                    $tanggal = date('d M', strtotime($row['TANGGAL']));
                    $index = array_search($tanggal, $labels);
                    if ($index !== false) {
                        $data[$index] = $row['JUMLAH'];
                    }
                }
                echo json_encode($data);
            }
        ?>;
        
        // Grafik peminjaman
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Jumlah Peminjaman',
                    data: data,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
</body>
</html>