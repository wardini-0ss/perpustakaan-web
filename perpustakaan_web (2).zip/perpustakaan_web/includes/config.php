<?php
$conn = oci_connect('C##BABA', '123', 'localhost:1521/ORCLPDB');
if (!$conn) {
    $e = oci_error();
    die("Koneksi gagal: " . $e['message']);
}
?>