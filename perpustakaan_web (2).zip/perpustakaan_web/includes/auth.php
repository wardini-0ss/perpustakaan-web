<?php
session_start();
require_once 'config.php';

function login($username, $password) {
    global $conn;
    
    $query = "SELECT id, username, password, role FROM users WHERE username = :username";
    $stmt = oci_parse($conn, $query);
    oci_bind_by_name($stmt, ':username', $username);
    oci_execute($stmt);
    
    if ($user = oci_fetch_assoc($stmt)) {
        if (password_verify($password, $user['PASSWORD'])) {
            $_SESSION['user_id'] = $user['ID'];
            $_SESSION['username'] = $user['USERNAME'];
            $_SESSION['role'] = $user['ROLE'];
            return true;
        }
    }
    return false;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] == 'admin';
}

function isAnggota() {
    return isLoggedIn() && $_SESSION['role'] == 'anggota';
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: ../index.php");
        exit();
    }
}

function redirectIfNotAdmin() {
    redirectIfNotLoggedIn();
    if (!isAdmin()) {
        header("Location: ../index.php");
        exit();
    }
}

function redirectIfNotAnggota() {
    redirectIfNotLoggedIn();
    if (!isAnggota()) {
        header("Location: ../index.php");
        exit();
    }
}
?>