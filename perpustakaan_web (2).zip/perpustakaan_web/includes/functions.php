<?php
function clean_input($data) {
    if (!isset($data) || $data === null) {
        return '';
    }
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return $data;
}
function is_username_exists($conn, $username) {
    $query = "SELECT id FROM users WHERE username = :username";
    $stmt = oci_parse($conn, $query);
    
    if (!$stmt) {
        $error = oci_error($conn);
        throw new Exception("Prepare failed: " . $error['message']);
    }
    
    oci_bind_by_name($stmt, ':username', $username);
    $result = oci_execute($stmt);
    
    if (!$result) {
        $error = oci_error($stmt);
        throw new Exception("Execute failed: " . $error['message']);
    }
    
    $row = oci_fetch_assoc($stmt);
    oci_free_statement($stmt);
    
    return ($row !== false);
}
?>