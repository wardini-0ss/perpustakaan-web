<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: anggota/dashboard.php");
    }
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = clean_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Username dan password harus diisi";
    } else {
        if (login($username, $password)) {
            if (isAdmin()) {
                header("Location: admin/dashboard.php");
            } else {
                header("Location: anggota/dashboard.php");
            }
            exit();
        } else {
            $error = "Username atau password salah";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .login-container {
            max-width: 1200px;
            margin: 0 auto;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .login-left {
            background: url('https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80') no-repeat center center;
            background-size: cover;
            color: white;
            padding: 4rem;
            position: relative;
        }
        
        .login-left::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(44, 62, 80, 0.8);
        }
        
        .login-left-content {
            position: relative;
            z-index: 1;
        }
        
        .login-right {
            background: white;
            padding: 4rem;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .logo img {
            height: 200px;
        }
        
        .welcome-text h2 {
            font-weight: 700;
            color: var(--secondary-color);
            margin-bottom: 1rem;
        }
        
        .welcome-text p {
            color: #7f8c8d;
            margin-bottom: 2rem;
        }
        
        .form-control {
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #dfe6e9;
            margin-bottom: 1.5rem;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-login {
            background-color: var(--primary-color);
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 600;
            width: 100%;
            margin-top: 1rem;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        
        .forgot-pass {
            text-align: right;
            margin-top: -10px;
            margin-bottom: 1.5rem;
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 2rem 0;
        }
        
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #dfe6e9;
        }
        
        .divider-text {
            padding: 0 1rem;
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        
        .social-login {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .social-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .social-btn:hover {
            transform: translateY(-3px);
        }
        
        .bg-google {
            background-color: #db4437;
        }
        
        .bg-facebook {
            background-color: #4267b2;
        }
        
        .bg-twitter {
            background-color: #1da1f2;
        }
        
        .register-link {
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .alert-notification {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 90%;
            max-width: 500px;
            animation: slideDown 0.5s ease-out;
        }
        
        @keyframes slideDown {
            from {
                top: -100px;
                opacity: 0;
            }
            to {
                top: 20px;
                opacity: 1;
            }
        }
        
        @media (max-width: 992px) {
            .login-left {
                display: none;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($_GET['registrasi']) && $_GET['registrasi'] == 'sukses'): ?>
        <div class="alert alert-success alert-notification alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i> Pendaftaran berhasil! Silakan login.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="container login-container">
        <div class="row g-0">
            <!-- Left Side - Welcome Section -->
            <div class="col-lg-6 login-left">
                <div class="login-left-content">
                    <h1 class="display-4 fw-bold mb-4">Selamat Datang</h1>
                    <p class="lead">Sistem Manajemen Perpustakaan Digital</p>
                    <div class="features mt-5">
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-book-open fa-lg me-3"></i>
                            <span>Koleksi buku terlengkap</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-clock fa-lg me-3"></i>
                            <span>Akses 24/7 dari mana saja</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-shield fa-lg me-3"></i>
                            <span>Sistem keamanan terjamin</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Side - Login Form -->
            <div class="col-lg-6 login-right">
                <div class="logo">
                    <img src="book_logo.jpg" alt="Logo Perpustakaan">
                </div>
                
                <div class="welcome-text">
                    <h2>Masuk ke Akun Anda</h2>
                    <p>Silakan masukkan username dan password Anda untuk mengakses sistem</p>
                </div>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" autocomplete="off">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required autofocus>
                        <label for="username"><i class="fas fa-user me-2"></i>Username</label>
                    </div>
                    
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        <label for="password"><i class="fas fa-lock me-2"></i>Password</label>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember">
                            <label class="form-check-label" for="remember">Ingat saya</label>
                        </div>
                        <a href="#" class="text-decoration-none">Lupa password?</a>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </button>
                    
                    <div class="divider">
                        <span class="divider-text">ATAU</span>
                    </div>
                    
                    <div class="social-login">
                        <a href="#" class="social-btn bg-google">
                            <i class="fab fa-google"></i>
                        </a>
                        <a href="#" class="social-btn bg-facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-btn bg-twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                    
                    <div class="register-link">
                        <p>Belum punya akun? <a href="daftar.php" class="text-decoration-none fw-bold">Daftar sekarang</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto close alert setelah 5 detik
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert-notification');
            alerts.forEach(alert => {
                new bootstrap.Alert(alert).close();
            });
        }, 5000);
        
        // Animasi input focus
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.querySelector('label').style.color = '#3498db';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.querySelector('label').style.color = '#6c757d';
            });
        });
    </script>
</body>
</html>