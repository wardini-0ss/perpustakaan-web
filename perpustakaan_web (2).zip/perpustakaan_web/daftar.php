<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $nama_lengkap = clean_input($_POST['nama_lengkap']);
    $username = clean_input($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $alamat = clean_input($_POST['alamat']);
    $email = clean_input($_POST['email']);
    $telepon = clean_input($_POST['telepon']);

    // Mulai transaksi database
    $conn->begin_transaction();

    try {
        // 1. Insert ke tabel users
        $stmt_user = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'anggota')");
        $stmt_user->bind_param("ss", $username, $password);
        $stmt_user->execute();
        $user_id = $conn->insert_id;
        $stmt_user->close();

        // 2. Insert ke tabel anggota
        $stmt_anggota = $conn->prepare("INSERT INTO anggota (user_id, nama, alamat, email, telepon) VALUES (?, ?, ?, ?, ?)");
        $stmt_anggota->bind_param("issss", $user_id, $nama_lengkap, $alamat, $email, $telepon);
        $stmt_anggota->execute();
        $stmt_anggota->close();

        // Commit transaksi
        $conn->commit();

        header("Location: index.php?registrasi=sukses");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Pendaftaran gagal: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Anggota</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Pendaftaran Anggota Perpustakaan</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" required>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="telepon" class="form-label">Nomor Telepon</label>
                                <input type="tel" class="form-control" id="telepon" name="telepon" required>
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="form-label">Alamat</label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Daftar</button>
                        </form>
                        <div class="text-center mt-3">
                            <p>Sudah punya akun? <a href="index.php">Login disini</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>